<?php

$hostname = "localhost";
$username = "root";
$password = "root";
$database = "db";

$conn = mysqli_connect($hostname, $username, $password, $database) or die("Database connection failed");

$base_url = "http://localhost/Educational_service/ES/ES/send_otp/animated-epic-php-user-management-system-main/";
$my_email = "code@akhfasoft.net";

?>