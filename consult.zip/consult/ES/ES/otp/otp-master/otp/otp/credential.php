<?php 
	/*Enter your API_KEY*/
	define("API_KEY", 'NDg3OTQzNGEzODc2NDg1MzcwNjg0MTQ0NmQ2ODRhNzY=');

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>