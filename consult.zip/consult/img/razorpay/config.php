<?php

$keyId = 'rzp_test_G1C6TBjpWDnR4h';
$keySecret = 'OokBSij6pK5qa9FHulc1HNzi';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
