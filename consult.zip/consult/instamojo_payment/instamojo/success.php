<?php
echo $_GET['payment_id'].'<br>';           // displaying payment id
echo $_GET['payment_request_id'].'<br>';    //payment request id
?>