<?php
  /*session_start();
  define("SITEURL",'http://3.109.14.4//consult/');  
  $servername = "localhost";
    $username = "ostechnix";
    $password = "Password123#@!";
    $dbname = "consultant_app";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }*/
 // starting session
 session_start();
 //site url
  define("SITEURL",'http://localhost/consult/');
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "consultant_app";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error)
    {
        die("Connection failed: " . $conn->connect_error);
    }
?>