<?php
include('indexDB.php');

$name = $_GET['fullname'];
$email = $_GET['email'];
$feed = $_GET['feedback'];

$sql= "INSERT INTO `feedback`(`user_name`, `feedback`, `email`) VALUES ('$name','$feed','$email')";
$res = mysqli_query($conn,$sql);
if ($res){
    header('Location: contact.html' );
    ?>
    <script>alert("YOUR FEEDBACK WAS NOTED,THANKS FOR GIVING FEEDBACK");</script>
<?php
	echo "YOUR FEEDBACK WAS NOTED,THANKS FOR GIVING FEEDBACK";
}
else{
    header('Location: contact.html' );
}




?>