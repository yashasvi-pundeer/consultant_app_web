// change the name ,password of database in db.php
you can import database-table from sql file subscriber.php
